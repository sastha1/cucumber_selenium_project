package steps;

import java.util.concurrent.TimeUnit;

import cucumber.api.PendingException;
import cucumber.api.java.en.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class StepsDef {
	
	public static RemoteWebDriver driver;
	
	@Before
	public void startTestScenario(Scenario sc) {
		System.out.println("I am starting the test scenario");

	}
	
	@After
	public void endTestScenario(Scenario sc) {
		System.out.println("I am ending the test scenario");

	}
	
	@Given("Launch the chrome browser")
	public void launchBrowser(){
	   System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
	   driver = new ChromeDriver();
	}
	

	@Given("Set timeout")
	public void setTimeout(){
	   driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}


	@Given("Open URL (.*)")
	public void enterURL(String url){
		launchBrowser();
	    driver.get(url);
	    setTimeout();
	}
	
	@When("I click on (.*)")
	public void enterUserName(String tabName){
	   driver.findElementByXPath("//a[contains(text(),'Weather')]").click();
		setTimeout();
	}
	

	


	@And("^Enter (.*) in search box$")
	public void enterLondonInSearchBox(String searchName) throws Throwable {
		driver.findElementByXPath("//input[@id='ls-c-search__input-label']").click();
		setTimeout();
		driver.findElementByXPath("//input[@id='ls-c-search__input-label']").sendKeys(searchName);

		driver.findElementByXPath("//*[@id='location-list']/li[1]/a").click();
		setTimeout();
	}

	@Then("^I verify and print tomorrow weather$")
	public void iVerifyAndPrintTomorrowWeather() throws Throwable {

		driver.findElementByXPath("//*[@id='daylink-1']").click();
		setTimeout();
		String text = driver.findElementByXPath("//a[@id='daylink-1']/div[4]/div[2]/div").getText();
		System.out.println(text);
	}
}
